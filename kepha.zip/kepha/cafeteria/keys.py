 

business_shortCode = "174379"  # Lipa Na Mpesa Shortcode
phone_number = "254797500447"
lipa_na_mpesa_passkey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919"
consumer_key = "B7LSImPhthGKu7b9gJr4cCi95IChotlC"
consumer_secret = "NA5gbBX265x8O7IV"
shortcode = "SHORTCODE"
test_msisdn = "TEST_MSISDN"

