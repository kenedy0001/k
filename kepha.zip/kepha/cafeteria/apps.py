from django.apps import AppConfig


class appConfig(AppConfig):
    name = 'cafeteria'
